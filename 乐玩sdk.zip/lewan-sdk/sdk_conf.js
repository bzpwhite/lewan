var sdk_conf = { 
    //.游戏唯一标识
    game: 'yuzhoudamaoxian',   
    //.当前游戏版本        
    version: '4.2.0',       
    //.banner广告单元id
    bannerAdUnitId: 'adunit-d6b9bab967f2f8b7',  
    //.video广告单元id   
    videoAdUnitId: 'adunit-3fa34dc8aada52e3',      


};
module.exports = sdk_conf;

